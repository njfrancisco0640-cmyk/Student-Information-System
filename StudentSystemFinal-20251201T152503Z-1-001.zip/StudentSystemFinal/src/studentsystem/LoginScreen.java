package studentsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.geom.RoundRectangle2D;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginScreen extends JFrame {
    private final JTextField usernameField;
    private final JPasswordField passwordField;
    private final JButton loginButton;
    private final JButton cancelButton;

    private static final Color ACCENT = new Color(0, 150, 136);
    private static final Color BG_TOP = new Color(248, 251, 250);
    private static final Color BG_BOTTOM = new Color(241, 247, 245);
    private static final Color TEXT_DARK = new Color(33, 33, 33);

    public LoginScreen() {
        
        setUndecorated(true);
        try {
            setShape(new RoundRectangle2D.Double(0, 0, 480, 420, 18, 18));
        } catch (Exception ignored) {}

        setSize(480, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Main panel
        JPanel main = new GradientPanel();
        main.setLayout(new BorderLayout());
        main.setBorder(BorderFactory.createEmptyBorder(28, 28, 28, 28));

        // Header
        JLabel icon = new JLabel("🔐", JLabel.CENTER);
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 36));
        icon.setForeground(ACCENT);

        JLabel title = new JLabel("WELCOME BACK", JLabel.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(TEXT_DARK);

        JLabel subtitle = new JLabel("Please sign in to continue", JLabel.CENTER);
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(new Color(90, 90, 90));

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.add(icon, BorderLayout.NORTH);
        header.add(title, BorderLayout.CENTER);
        header.add(subtitle, BorderLayout.SOUTH);
        header.setBorder(BorderFactory.createEmptyBorder(4, 0, 12, 0));

        // Form
        JPanel formCard = new RoundedPanel(12, Color.WHITE);
        formCard.setLayout(new GridBagLayout());
        formCard.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;

        JLabel userLabel = new JLabel("Username");
        userLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        userLabel.setForeground(TEXT_DARK);
        formCard.add(userLabel, gbc);

        usernameField = new JTextField();
        styleField(usernameField);
        gbc.gridy++;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        formCard.add(usernameField, gbc);

        gbc.gridy++;
        gbc.fill = GridBagConstraints.NONE;
        JLabel passLabel = new JLabel("Password");
        passLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        passLabel.setForeground(TEXT_DARK);
        formCard.add(passLabel, gbc);

        passwordField = new JPasswordField();
        styleField(passwordField);
        gbc.gridy++;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        formCard.add(passwordField, gbc);

        // Buttons
        JPanel btnPanel = new JPanel(new GridLayout(1, 2, 12, 0));
        btnPanel.setOpaque(false);
        loginButton = createPrimaryButton("Login");
        cancelButton = createSecondaryButton("Cancel");

        btnPanel.add(loginButton);
        btnPanel.add(cancelButton);

        gbc.gridy++;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        formCard.add(btnPanel, gbc);

        // Close icon bottom-right
        JButton closeBtn = new JButton("x");
        closeBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeBtn.setForeground(new Color(90, 90, 90));
        closeBtn.setContentAreaFilled(false);
        closeBtn.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
        closeBtn.addActionListener(e -> System.exit(0));

        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        footer.add(closeBtn, BorderLayout.EAST);

        main.add(header, BorderLayout.NORTH);
        main.add(formCard, BorderLayout.CENTER);
        main.add(footer, BorderLayout.SOUTH);

        add(main);

        // listeners
        loginButton.addActionListener(this::onLogin);
        cancelButton.addActionListener(e -> System.exit(0));
        passwordField.addActionListener(this::onLogin);

        // focus handling
        setAlwaysOnTop(true);
        setAlwaysOnTop(false);
    }

    private void onLogin(ActionEvent e) {
    String user = usernameField.getText().trim();
    String pass = new String(passwordField.getPassword());

    if (user.isEmpty() || pass.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please fill out all fields.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // SQL query
    String sql = "SELECT * FROM User WHERE username=? AND password=?";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setString(1, user);
        pst.setString(2, pass);

        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            loginSuccess();
        } else {
            loginFailed();
        }

    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this,
                "Database Error: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}

    private void loginSuccess() {
        loginButton.setText("Success");
        loginButton.setBackground(new Color(76, 175, 80));
        // quick loading then open interface
        new Timer(800, ev -> {
            dispose();
            SwingUtilities.invokeLater(() -> new StudentInfoSystem().setVisible(true));
        }) {{
            setRepeats(false);
            start();
        }};
    }

    private void loginFailed() {
        // shake animation
        final Point original = getLocation();
        Timer t = new Timer(40, null);
        t.addActionListener(new AbstractAction() {
            int count = 0;
            @Override
            public void actionPerformed(ActionEvent e) {
                int offset = (count % 2 == 0) ? 10 : -10;
                setLocation(original.x + offset, original.y);
                count++;
                if (count > 6) {
                    t.stop();
                    setLocation(original);
                    JOptionPane.showMessageDialog(LoginScreen.this,
                            "Invalid username or password", "Login Failed", JOptionPane.ERROR_MESSAGE);
                    passwordField.setText("");
                    usernameField.requestFocusInWindow();
                }
            }
        });
        t.start();
    }

    private void styleField(JTextField f) {
        f.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        f.setBackground(Color.WHITE);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
    }

    private JButton createPrimaryButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(ACCENT);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        return b;
    }

    private JButton createSecondaryButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(new Color(235, 235, 235));
        b.setForeground(new Color(70, 70, 70));
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        return b;
    }

    // rounded design
    private static class RoundedPanel extends JPanel {
        private final int radius;
        private final Color bg;

        public RoundedPanel(int radius, Color bg) {
            this.radius = radius;
            this.bg = bg;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(bg);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);

            // subtle border
            g2.setColor(new Color(220, 220, 220));
            g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, radius, radius);
            g2.dispose();
        }
    }

    // gradient background panel
    private static class GradientPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            GradientPaint gp = new GradientPaint(0, 0, BG_TOP, getWidth(), getHeight(), BG_BOTTOM);
            g2.setPaint(gp);
            g2.fillRect(0, 0, getWidth(), getHeight());

            // subtle whites
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.06f));
            g2.setColor(Color.WHITE);
            g2.fillOval(-120, -80, 260, 260);
            g2.fillOval(getWidth()-180, getHeight()-200, 320, 320);

            g2.dispose();
        }
    }

    @Override
    public void setVisible(boolean visible) {
        super.setVisible(visible);
        if (visible) {
            toFront();
            requestFocus();
            setAlwaysOnTop(true);
            setAlwaysOnTop(false);
        }
    }
}
