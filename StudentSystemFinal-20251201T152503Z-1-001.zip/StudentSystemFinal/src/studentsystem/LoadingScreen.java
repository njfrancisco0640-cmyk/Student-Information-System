package studentsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;


public class LoadingScreen extends JWindow {
    private final JProgressBar progressBar;
    private final JLabel percentLabel;
    private final JLabel statusLabel;
    private Timer timer;
    private Timer dotsTimer;
    private int progress = 0;

    // color palette
    private static final Color ACCENT = new Color(0, 150, 136);
    private static final Color BG_TOP = new Color(225, 245, 244);
    private static final Color BG_BOTTOM = new Color(240, 250, 249);
    private static final Color TEXT_DARK = new Color(44, 44, 44);
    private static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 26);
    private static final Font SUB_FONT = new Font("Segoe UI", Font.PLAIN, 14);

    public LoadingScreen() {
        try {
            setShape(new RoundRectangle2D.Double(0, 0, 800, 380, 24, 24));
        } catch (Exception ignored) { }

        setSize(800, 380);
        setLocationRelativeTo(null);

        // main panel
        JPanel panel = new GradientPanel();
        panel.setLayout(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(28, 28, 28, 28));

        // Header
        JLabel iconLabel = new JLabel("🎓", JLabel.CENTER);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 44));
        iconLabel.setForeground(ACCENT);

        JLabel titleLabel = new JLabel("STUDENT INFORMATION SYSTEM", JLabel.CENTER);
        titleLabel.setFont(TITLE_FONT);
        titleLabel.setForeground(TEXT_DARK);

        JLabel subtitle = new JLabel("Managing Student Records — Loading...", JLabel.CENTER);
        subtitle.setFont(SUB_FONT);
        subtitle.setForeground(TEXT_DARK);

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.add(iconLabel, BorderLayout.NORTH);
        header.add(titleLabel, BorderLayout.CENTER);
        header.add(subtitle, BorderLayout.SOUTH);
        header.setBorder(BorderFactory.createEmptyBorder(8, 0, 16, 0));

        // loading area
        JPanel center = new JPanel(new BorderLayout(0, 12));
        center.setOpaque(false);
        JLabel loadingLabel = new JLabel("Loading system components", JLabel.CENTER);
        loadingLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        loadingLabel.setForeground(TEXT_DARK);

        JLabel dotsLabel = new JLabel("", JLabel.CENTER);
        dotsLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        dotsLabel.setForeground(ACCENT);

        progressBar = new JProgressBar(0, 100) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // background
                g2.setColor(new Color(230, 230, 230));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);

                // progress fill
                int w = (int) ((getWidth() - 4) * ((double) getValue() / getMaximum()));
                if (w > 0) {
                    GradientPaint gp = new GradientPaint(0, 0, ACCENT.brighter(), w, 0, ACCENT.darker());
                    g2.setPaint(gp);
                    g2.fillRoundRect(2, 2, Math.max(3, w - 2), getHeight() - 4, 10, 10);
                }

                // border
                g2.setColor(new Color(200, 200, 200));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
                g2.dispose();
            }
        };
        progressBar.setPreferredSize(new Dimension(600, 22));
        progressBar.setOpaque(false);
        progressBar.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        progressBar.setStringPainted(false);

        percentLabel = new JLabel("0%", JLabel.CENTER);
        percentLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        percentLabel.setForeground(TEXT_DARK);

        statusLabel = new JLabel("Initializing...", JLabel.LEFT);
        statusLabel.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        statusLabel.setForeground(TEXT_DARK);

        center.add(loadingLabel, BorderLayout.NORTH);
        center.add(dotsLabel, BorderLayout.CENTER);

        JPanel progressWrap = new JPanel(new BorderLayout(8, 8));
        progressWrap.setOpaque(false);
        progressWrap.setBorder(BorderFactory.createEmptyBorder(8, 80, 0, 80));
        progressWrap.add(progressBar, BorderLayout.CENTER);

        JPanel pSouth = new JPanel(new BorderLayout());
        pSouth.setOpaque(false);
        pSouth.add(statusLabel, BorderLayout.WEST);
        pSouth.add(percentLabel, BorderLayout.EAST);
        progressWrap.add(pSouth, BorderLayout.SOUTH);

        center.add(progressWrap, BorderLayout.SOUTH);

        panel.add(header, BorderLayout.NORTH);
        panel.add(center, BorderLayout.CENTER);

        getContentPane().add(panel);

        // dots timer n status prog
        dotsTimer = new Timer(450, new ActionListener() {
            private int dotCount = 0;
            private final String[] statuses = {
                    "Initializing modules...", "Loading UI assets...", "Preparing data...",
                    "Establishing connections...", "Finalizing setup..."
            };
            private int statusIndex = 0;

            @Override
            public void actionPerformed(ActionEvent e) {
                dotCount = (dotCount + 1) % 4;
                StringBuilder dots = new StringBuilder();
                for (int i = 0; i < dotCount; i++) dots.append(".");
                dotsLabel.setText(dots.toString());

                // update status
                if (progress >= (statusIndex + 1) * (100 / statuses.length) && statusIndex < statuses.length - 1) {
                    statusIndex++;
                    statusLabel.setText(statuses[statusIndex]);
                }
            }
        });
        dotsTimer.start();

        showLoading();
    }

    private void showLoading() {
        setVisible(true);

        timer = new Timer(30, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                progress = Math.min(100, progress + 1);
                progressBar.setValue(progress);
                percentLabel.setText(progress + "%");

                if (progress >= 100) {
                    timer.stop();
                    if (dotsTimer != null) dotsTimer.stop();
                    // delay
                    new Timer(450, ev -> {
                        dispose();
                        SwingUtilities.invokeLater(() -> {
                            new LoginScreen().setVisible(true);
                        });
                    }) {{
                        setRepeats(false);
                        start();
                    }};
                }
            }
        });
        timer.start();
    }

    // panel
    private static class GradientPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            GradientPaint gp = new GradientPaint(0, 0, BG_TOP, getWidth(), getHeight(), BG_BOTTOM);
            g2.setPaint(gp);
            g2.fillRect(0, 0, getWidth(), getHeight());

            // circle des
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.08f));
            g2.setColor(Color.WHITE);
            g2.fillOval(-80, -80, 220, 220);
            g2.fillOval(getWidth() - 180, getHeight() - 180, 300, 300);

            g2.dispose();
        }
    }

    // entry
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            System.setProperty("awt.useSystemAAFontSettings", "on");
            System.setProperty("swing.aatext", "true");
        } catch (Exception ignored) { }

        SwingUtilities.invokeLater(LoadingScreen::new);
    }
}
