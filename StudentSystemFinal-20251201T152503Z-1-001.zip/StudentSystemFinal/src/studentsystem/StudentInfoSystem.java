package studentsystem;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.sql.*;

public class StudentInfoSystem extends JFrame {
    

    private final DefaultTableModel tableModel;
    private final JTable studentTable;
    private final JTextField idField, nameField, courseField, yearField, emailField;
    private final JButton addButton, updateButton, deleteButton, clearButton, refreshButton;

    private static final Color CANDY_PINK    = new Color(255, 107, 129);
    private static final Color CANDY_TEAL    = new Color(0, 150, 136);
    private static final Color CANDY_PURPLE  = new Color(145, 92, 199);
    private static final Color CANDY_YELLOW  = new Color(255, 205, 86);
    private static final Color CARD_BG       = new Color(255, 255, 255);
    private static final Color TEXT_DARK     = new Color(30, 30, 30);

    public StudentInfoSystem() {
        setUndecorated(true);
        try { setShape(new RoundRectangle2D.Double(0, 0, 1100, 700, 22, 22)); } catch (Exception ignored) {}
        setSize(1100, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        CandyBackground main = new CandyBackground();
        main.setLayout(new BorderLayout());
        main.setBorder(new EmptyBorder(18, 18, 18, 18));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JLabel title = new JLabel("STUDENT INFORMATION MANAGEMENT SYSTEM", JLabel.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(TEXT_DARK);

        JLabel subtitle = new JLabel("Make student informations organized", JLabel.CENTER);
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(new Color(80, 80, 80));

        header.add(title, BorderLayout.NORTH);
        header.add(subtitle, BorderLayout.SOUTH);
        header.setBorder(BorderFactory.createEmptyBorder(6, 0, 14, 0));

        // Left: Form n buttons
        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setPreferredSize(new Dimension(380, 0));
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));

        RoundedCard formCard = new RoundedCard(14, CARD_BG);
        formCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        formCard.setLayout(new BoxLayout(formCard, BoxLayout.Y_AXIS));
        formCard.setBorder(new EmptyBorder(16, 16, 16, 16));

        JLabel formTitle = new JLabel("Add / Edit Student", JLabel.LEFT);
        formTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        formTitle.setForeground(TEXT_DARK);
        formTitle.setBorder(new EmptyBorder(0, 0, 10, 0));
        formTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel fields = new JPanel();
        fields.setOpaque(false);
        fields.setLayout(new BoxLayout(fields, BoxLayout.Y_AXIS));


        idField = createStyledField(true, "Auto-generated");
        nameField = createStyledField(false, "e.g. Nathalie Jane Francisco");
        courseField = createStyledField(false, "e.g. BS Information Technology");
        yearField = createStyledField(false, "e.g. 2nd Year");
        emailField = createStyledField(false, "e.g. student@school.edu");

        fields.add(labelled("Student ID:", idField));
        fields.add(Box.createVerticalStrut(5));
        fields.add(labelled("Full Name:", nameField));
        fields.add(Box.createVerticalStrut(5));
        fields.add(labelled("Course:", courseField));
        fields.add(Box.createVerticalStrut(5));
        fields.add(labelled("Year Level:", yearField));
        fields.add(Box.createVerticalStrut(5));
        fields.add(labelled("Email:", emailField));
        fields.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Buttons panel 
        // Buttons panel (2 rows)
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setOpaque(false);
        // 2 rows, 3 columns - we'll add a filler for the last cell
        buttonsPanel.setLayout(new GridLayout(2, 3, 12, 8));
        buttonsPanel.setBorder(new EmptyBorder(16, 0, 0, 0));
        // limit height so it doesn't get squashed or push layout unexpectedly
        buttonsPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));
        buttonsPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        //
        addButton     = new RoundedButton("Add", CANDY_PINK);
        updateButton  = new RoundedButton("Update", CANDY_YELLOW);
        deleteButton  = new RoundedButton("Delete", CANDY_PURPLE);
        clearButton   = new RoundedButton("Clear", new Color(200, 200, 200));
        refreshButton = new RoundedButton("Refresh", CANDY_TEAL);

        // Add five buttons + filler to keep grid balanced (6 cells)
        buttonsPanel.add(addButton);
        buttonsPanel.add(updateButton);
        buttonsPanel.add(deleteButton);
        buttonsPanel.add(clearButton);
        buttonsPanel.add(refreshButton);
        buttonsPanel.add(new JPanel()); // filler


        // form card
        formCard.add(formTitle);
        formCard.add(fields);
        formCard.add(buttonsPanel);

        // Add formCard to left side
        left.add(formCard);
        left.add(Box.createVerticalGlue());

        // Right: table
        JPanel right = new JPanel(new BorderLayout());
        right.setOpaque(false);
        RoundedCard tableCard = new RoundedCard(14, CARD_BG);
        tableCard.setBorder(new EmptyBorder(12, 12, 12, 12));
        tableCard.setLayout(new BorderLayout());

        JLabel tableTitle = new JLabel("Students List", JLabel.LEFT);
        tableTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        tableTitle.setForeground(TEXT_DARK);
        tableTitle.setBorder(new EmptyBorder(0, 0, 8, 0));

        String[] cols = {"ID", "Name", "Course", "Year Level", "Email"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };
        studentTable = new JTable(tableModel);
        styleTable();

        JScrollPane sp = new JScrollPane(studentTable);
        sp.setBorder(BorderFactory.createEmptyBorder());

        tableCard.add(tableTitle, BorderLayout.NORTH);
        tableCard.add(sp, BorderLayout.CENTER);

        right.add(tableCard, BorderLayout.CENTER);

        JPanel content = new JPanel(new BorderLayout(18, 0));
        content.setOpaque(false);
        content.add(left, BorderLayout.WEST);
        content.add(right, BorderLayout.CENTER);

        // Footer
        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);

        JLabel hint = new JLabel("Tip: Fill the fields then click Add. Select a row to edit or delete.", JLabel.LEFT);
        hint.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        hint.setForeground(new Color(90, 90, 90));
        hint.setBorder(new EmptyBorder(6, 6, 6, 6));

        JButton closeBtn = new RoundedButton("x", new Color(240, 80, 100));
        closeBtn.addActionListener(e -> System.exit(0));

        JPanel rPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rPanel.setOpaque(false);
        rPanel.add(closeBtn);

        footer.add(hint, BorderLayout.WEST);
        footer.add(rPanel, BorderLayout.EAST);

        main.add(header, BorderLayout.NORTH);
        main.add(content, BorderLayout.CENTER);
        main.add(footer, BorderLayout.SOUTH);
        add(main);

        wireListeners();
        setAlwaysOnTop(true);
        setAlwaysOnTop(false);
    }

    private void wireListeners() {
        addButton.addActionListener(e -> addStudent());
        updateButton.addActionListener(e -> updateStudent());
        deleteButton.addActionListener(e -> deleteStudent());
        clearButton.addActionListener(e -> clearForm());
        refreshButton.addActionListener(e -> refreshTable());

        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);

        studentTable.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
            boolean selected = studentTable.getSelectedRow() >= 0;
            updateButton.setEnabled(selected);
            deleteButton.setEnabled(selected);
            if (!e.getValueIsAdjusting()) displaySelected();
        });

        studentTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && studentTable.getSelectedRow() != -1) {
                    int sel = studentTable.convertRowIndexToModel(studentTable.getSelectedRow());
                    loadStudentToForm(sel);
                }
            }
        });

        emailField.addActionListener(e -> {
            if (idField.getText().trim().isEmpty()) addStudent();
            else updateStudent();
        });
    }

    // Tableeee
    private void addStudent() {
    String name = trimPlaceholder(nameField);
    String course = trimPlaceholder(courseField);
    String year = trimPlaceholder(yearField);
    String email = trimPlaceholder(emailField);

    if (!validateForm(false, name, course, year, email)) return;

    try (Connection conn = DatabaseConnection.getConnection()) {
        String sql = "INSERT INTO students (name, course, year_level, email) VALUES (?, ?, ?, ?)";
        PreparedStatement pst = conn.prepareStatement(sql);

        pst.setString(1, name);
        pst.setString(2, course);
        pst.setString(3, year);
        pst.setString(4, email);

        pst.executeUpdate();

        JOptionPane.showMessageDialog(this, "Student added successfully!");
        refreshTable();
        clearForm();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error adding student!");
        e.printStackTrace();
    }
    }
    private void updateStudent() {
    if (idField.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Select a student first.");
        return;
    }

    try (Connection conn = DatabaseConnection.getConnection()) {

        String sql = "UPDATE students SET name=?, course=?, year_level=?, email=? WHERE id=?";
        PreparedStatement pst = conn.prepareStatement(sql);

        pst.setString(1, trimPlaceholder(nameField));
        pst.setString(2, trimPlaceholder(courseField));
        pst.setString(3, trimPlaceholder(yearField));
        pst.setString(4, trimPlaceholder(emailField));
        pst.setInt(5, Integer.parseInt(idField.getText()));

        pst.executeUpdate();

        JOptionPane.showMessageDialog(this, "Student updated!");
        refreshTable();
        clearForm();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Update failed!");
        e.printStackTrace();
    }
}
    private void deleteStudent() {
    if (idField.getText().trim().isEmpty()) return;

    int confirm = JOptionPane.showConfirmDialog(
            this,
            "Delete this student permanently?",
            "Confirm",
            JOptionPane.YES_NO_OPTION
    );

    if (confirm != JOptionPane.YES_OPTION) return;

    try (Connection conn = DatabaseConnection.getConnection()) {

        String sql = "DELETE FROM students WHERE id=?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, Integer.parseInt(idField.getText()));

        pst.executeUpdate();

        JOptionPane.showMessageDialog(this, "Student deleted!");
        refreshTable();
        clearForm();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Delete failed!");
        e.printStackTrace();
    }
}
    private void clearForm() {
        idField.setText("");
        resetPlaceholder(nameField);
        resetPlaceholder(courseField);
        resetPlaceholder(yearField);
        resetPlaceholder(emailField);
        studentTable.clearSelection();
        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);
    }
    private void refreshTable() {
    tableModel.setRowCount(0);

    try (Connection conn = DatabaseConnection.getConnection()) {

        String sql = "SELECT * FROM students";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            tableModel.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("course"),
                    rs.getString("year_level"),
                    rs.getString("email")
            });
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Failed to load data!");
        e.printStackTrace();
    }
}
    private void displaySelected() {
        int viewRow = studentTable.getSelectedRow();
        if (viewRow >= 0) {
            int modelRow = studentTable.convertRowIndexToModel(viewRow);
            loadStudentToForm(modelRow);
        }
    }

    private void loadStudentToForm(int modelRow) {
        if (modelRow < 0 || modelRow >= tableModel.getRowCount()) return;
        idField.setText(String.valueOf(tableModel.getValueAt(modelRow, 0)));
        nameField.setForeground(TEXT_DARK);
        nameField.setText(String.valueOf(tableModel.getValueAt(modelRow, 1)));
        courseField.setForeground(TEXT_DARK);
        courseField.setText(String.valueOf(tableModel.getValueAt(modelRow, 2)));
        yearField.setForeground(TEXT_DARK);
        yearField.setText(String.valueOf(tableModel.getValueAt(modelRow, 3)));
        emailField.setForeground(TEXT_DARK);
        emailField.setText(String.valueOf(tableModel.getValueAt(modelRow, 4)));
    }

    private boolean validateForm(boolean isUpdate, String name, String course, String year, String email) {
        if (name.isEmpty() || course.isEmpty() || year.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.", "Missing data", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (!email.contains("@") || !email.contains(".")) {
            JOptionPane.showMessageDialog(this, "Please enter a valid email address.", "Invalid email", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (name.length() < 3) {
            JOptionPane.showMessageDialog(this, "Name seems too short.", "Invalid name", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    // UI helpers
    private JTextField createStyledField(boolean readonly, String placeholder) {
        JTextField f = new JTextField();
        f.setEditable(!readonly);
        f.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        f.setBackground(CARD_BG);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                new EmptyBorder(8, 10, 8, 10)
        ));
        addPlaceholderBehavior(f, placeholder, readonly);
        return f;
    }
    private void addPlaceholderBehavior(JTextField f, String placeholder, boolean readonly) {
        Color hint = new Color(150,150,150);
        if (f.getText().isEmpty()) {
            f.setForeground(hint);
            f.setText(placeholder);
        }
        f.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) {
                if (f.getText().equals(placeholder)) {
                    f.setText("");
                    f.setForeground(TEXT_DARK);
                }
            }
            @Override public void focusLost(FocusEvent e) {
                if (f.getText().trim().isEmpty()) {
                    f.setForeground(hint);
                    f.setText(placeholder);
                    if (readonly) f.setText(placeholder);
                }
            }
        });
    }
    private void resetPlaceholder(JTextField f) {
        f.setForeground(new Color(150,150,150));
        if (f == nameField) f.setText("e.g. Nathalie Jane Francisco");
        else if (f == courseField) f.setText("e.g. BS Information Technology");
        else if (f == yearField) f.setText("e.g. 2nd Year");
        else if (f == emailField) f.setText("e.g. student@school.edu");
    }
    private String trimPlaceholder(JTextField f) {
        String t = f.getText().trim();
        if (t.isEmpty()) return "";
        Color fg = f.getForeground();
        if (fg != null && fg.getRed() == 150 && fg.getGreen() == 150 && fg.getBlue() == 150) {
            return "";
        }
        return t;
    }
    private JPanel labelled(String labelText, JComponent field) {
        JPanel p = new JPanel(new BorderLayout(6, 4));
        p.setOpaque(false);
        JLabel l = new JLabel(labelText);
        l.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l.setForeground(TEXT_DARK);
        p.add(l, BorderLayout.NORTH);
        p.add(field, BorderLayout.CENTER);
        return p;
    }

    private String asMultilineLabel(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private String asMultilineLabel(String string, String add) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // rounded Button
    public static class RoundedButton extends JButton {
        private final Color background;
        private final int arc;
        public RoundedButton(String text, Color bgColor) {
            super(text);
            this.background = bgColor;
            this.arc = 20;
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setForeground(Color.WHITE);
            setFont(new Font("Segoe UI", Font.BOLD, 14));
            setMargin(new Insets(8, 10, 8, 10));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            g2.setColor(isEnabled() ? background : new Color(210, 210, 210));
            g2.fillRoundRect(0, 0, w, h, arc, arc);
            super.paintComponent(g2);
            g2.dispose();
        }
        @Override
        protected void paintBorder(Graphics g) {
            // no border for clean look!
        }
        @Override
        public void setContentAreaFilled(boolean b) {}
    }

    // Table des
    private void styleTable() {
        studentTable.setRowHeight(38);
        studentTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        studentTable.setForeground(TEXT_DARK);
        studentTable.setSelectionBackground(new Color(CANDY_TEAL.getRed(), CANDY_TEAL.getGreen(), CANDY_TEAL.getBlue(), 90));
        studentTable.setSelectionForeground(TEXT_DARK);
        studentTable.setGridColor(new Color(245, 245, 245));
        studentTable.setShowGrid(true);
        studentTable.setIntercellSpacing(new Dimension(6, 6));
        studentTable.setFillsViewportHeight(true);
        studentTable.setAutoCreateRowSorter(true);

        DefaultTableCellRenderer zebra = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (isSelected) {
                    c.setBackground(new Color(CANDY_TEAL.getRed(), CANDY_TEAL.getGreen(), CANDY_TEAL.getBlue(), 80));
                } else {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(255, 250, 252));
                }
                setBorder(new EmptyBorder(4,8,4,8));
                return c;
            }
        };
        for (int i = 0; i < studentTable.getColumnCount(); i++) {
            studentTable.getColumnModel().getColumn(i).setCellRenderer(zebra);
        }
       JTableHeader header = studentTable.getTableHeader();
header.setFont(new Font("Segoe UI", Font.BOLD, 13));
header.setBackground(CANDY_PURPLE);
header.setForeground(TEXT_DARK);
header.setReorderingAllowed(false);
header.setPreferredSize(new Dimension(header.getWidth(), 36));
    }

    
    private static class CandyBackground extends JPanel {
        CandyBackground() { setOpaque(false); }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color top = new Color(255, 248, 250);
            Color bottom = new Color(250, 255, 253);
            GradientPaint gp = new GradientPaint(0, 0, top, getWidth(), getHeight(), bottom);
            g2.setPaint(gp);
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.12f));
            g2.setColor(CANDY_PINK);
            g2.fillOval(-80, -40, 220, 220);
            g2.setColor(CANDY_TEAL);
            g2.fillOval(getWidth() - 180, getHeight() - 200, 320, 320);
            g2.setColor(CANDY_PURPLE);
            g2.fillOval(getWidth() - 120, 40, 200, 200);
            g2.dispose();
        }
    }
    // Round card
    private static class RoundedCard extends JPanel {
        private final int radius;
        private final Color bg;
        RoundedCard(int radius, Color bg) { this.radius = radius; this.bg = bg; setOpaque(false); }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(bg);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g2.setColor(new Color(235,235,235));
            g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, radius, radius);
            g2.dispose();
        }
    }
    private static class Student {
        int id; String name, course, yearLevel, email;
        Student(int id, String name, String course, String yearLevel, String email) {
            this.id = id; this.name = name; this.course = course; this.yearLevel = yearLevel; this.email = email;
        }
    }
   
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            System.setProperty("awt.useSystemAAFontSettings", "on");
            System.setProperty("swing.aatext", "true");
        } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new StudentInfoSystem()
                
                .setVisible(true));
    }
}